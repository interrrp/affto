# Ascension: Fight For The Orb — UI kit

Resource pack for Minecraft **26.1 – 26.3** (`min_format` 84, `max_format` 97).
Everything lives in its own namespace (`ascension`), so it stacks on top of any other
pack without overwriting vanilla files.

Companion datapack: **Ascension-Setup** — `/function ascension:setup`, `ascension:teams`,
`ascension:clear`.

## Logo glyphs

Cut from the `remove.bg` artwork, resized with premultiplied alpha (no dark fringing).

| Glyph | Character | Size | Use |
|---|---|---|---|
| `logo` | `\uE000` | 251 × 27 | sidebar title |
| `logo_small` | `\uE001` | 168 × 18 | tablist header, tight spaces |
| `logo_large` | `\uE002` | 363 × 39 | menu / title screens |
| `logo_header` | `\uE005` | 112 × 12 | **sidebar title** (fits the 9 px strip) |
| `title` | `\uE003` | 252 × 42 | two-line block (wordmark + tagline) |
| `title_large` | `\uE004` | 408 × 68 | two-line block, large |
| `rule` | `\uE0A0` | 160 × 2 | divider line |

All six logo textures are cut from `Screenshot_20261030_182941.png` (the clean export,
not the remove.bg one). Its alpha is a hard mask with clean edge colour — 6.4 k
partial-alpha pixels vs 34 k in the remove.bg render, whose edges were dark-fringed —
so no decontamination pass is needed. Resizing is done in premultiplied alpha, and the
112 × 12 header gets an alpha gamma of 0.8 so the strokes survive a 6× downscale.

## Icons

| Glyph | Character | Icon |
|---|---|---|
| orb | `\uE010` | ender eye |
| sword | `\uE011` | iron sword |
| sword (diamond) | `\uE012` | diamond sword |
| crown | `\uE013` | golden helmet |
| coin | `\uE014` | gold ingot |
| timer | `\uE015` | clock (`clock_00` frame) |
| star | `\uE016` | nether star |
| heal | `\uE017` | golden apple |
| fire | `\uE018` | blaze powder |
| pearl | `\uE019` | ender pearl |
| kit | `\uE01A` | enchanted book |
| totem | `\uE01B` | totem of undying |
| arrow | `\uE01C` | arrow |
| xp | `\uE01D` | experience bottle |
| **Elytrians** | `\uE020` | elytra |
| **Avians** | `\uE021` | feather |
| **Paladins** | `\uE022` | iron chestplate |
| **Merlings** | `\uE023` | heart of the sea |

Icons reuse vanilla item textures, so they always match the loaded pack and stay crisp
at any GUI scale.

## Teams

| Team | Team colour | Icon |
|---|---|---|
| Purple Elytrians | `light_purple` | elytra |
| Blue Avians | `aqua` | feather |
| Red Paladins | `red` | iron chestplate |
| Orange Merlings | `gold` | heart of the sea |

Team prefix = icon glyph only (a one-space pad sits outside the font element). The
prefix applies to every member name, so it must never carry the colour word — a
`"Purple "` prefix would render every player as "Purple Steve" in the tab list.

The sidebar rows do not rely on the prefix for their label. Each row is a one-word
score holder with a per-score display name and a matching number format:

```mcfunction
scoreboard players set Elytrians asc 12
team join elytrians Elytrians
scoreboard players display name Elytrians asc {"text":"Purple Elytrians"}
scoreboard players display numberformat Elytrians asc styled {"color":"light_purple"}
```

`display name` supplies the spaced label, the team prefix supplies the icon, the team
colour tints both, and `display numberformat styled` tints the score — otherwise the
sidebar default (`StyledFormat.SIDEBAR_DEFAULT`) draws every number red.

## Offsets

`\uE100`–`\uE1FF` = advance +1 … +256 px
`\uE200`–`\uE27F` = advance −1 … −128 px

```json
[{"text":"ORB","color":"#D8D8D8"},
 {"text":"\uE120","font":"ascension:ui"},
 {"text":"12"}]
```

## Using a glyph

```mcfunction
/title @a title {"text":"\uE001","font":"ascension:ui"}
/scoreboard objectives modify asc displayname {"text":"","extra":[{"text":"\uE005","font":"ascension:ui"},{"text":"   ROUND 3","color":"#FFBD59"}]}
```

## Palette

| Use | Hex |
|---|---|
| Gold (primary) | `#FFBD59` |
| Deep blue (background) | `#04445E` |
| Sky (accent) | `#7FD8F0` |
| Ink | `#0B1A22` |
| Muted grey | `#8A9AA3` |

## Notes

- `pack.mcmeta` declares `min_format: 84` / `max_format: 200` — the same
  `min_format`/`max_format` style VanillaTweaks uses. Lower `min_format` if you need
  older clients.
- **Team colours must be vanilla names.** `/team modify <team> color` uses
  `TeamColorArgument`, which resolves `TeamColor.byName()` — the 16 named colours
  only. A hex value throws `argument.color.invalid`. That also means the sidebar's
  score numbers (which inherit the team colour) are limited to those 16. Text
  components elsewhere *do* accept hex, so the objective title still uses `#FFBD59`.
- The datapack auto-runs on `/reload` via `data/minecraft/tags/function/load.json`.
  Delete that file if you'd rather run `/function ascension:setup` manually.

## 26.3 texture renames

Two vanilla icons this kit originally used no longer exist as `item/*.png` in 26.3:
`clock` is now `clock_00` … `clock_63` (animation frames) and `shield` is rendered by a
special renderer with no item texture. The kit uses `clock_00` and `iron_chestplate`
instead. Any icon reference can be swapped by editing `assets/ascension/font/ui.json` —
just keep the `.png` on the end of `file`.

## Gotchas (learned the hard way)

**Scope `font` to the glyph, never the parent.** `"font"` is inherited by child
elements, so

```json
{"text":"\uE001","font":"ascension:ui","extra":[{"text":"  ROUND 3"}]}
```

pushes `ROUND 3` through `ascension:ui` as well — and that font has no ASCII glyphs,
so the text draws as missing-glyph boxes on top of the wordmark. Correct form:

```json
{"text":"","extra":[
  {"text":"\uE001","font":"ascension:ui"},
  {"text":"    ROUND 3","color":"#FFBD59"}
]}
```

**Spaces belong outside the font element too** — same reason. `ascension:ui` now
carries a 4 px space advance as a safety net, but keeping spaces in the default font
is the reliable form.

**Glyph ascent and the sidebar title.** For a normal line, a glyph's bottom edge sits
on the text baseline. With the vanilla line (height 9, ascent 7):

```
glyph_bottom = line_top + 7 - ascent + height
```

so `ascent = height` puts the icon on the baseline. The sidebar title strip, however,
is a fixed **9 px** box and the first scoreboard entry begins exactly at its bottom
edge (`Hud.displayScoreboardSidebar`). A tall glyph therefore draws over the first row:

| Glyph | height | ascent | bottom vs. line | result |
|---|---|---|---|---|
| `\uE001` logo_small | 18 | 12 | +4 px | 4 px into the first row |
| `\uE005` logo_header | 12 | 10 | 0 px | flush, 2 px above the strip |

Hence the sidebar title uses `\uE005` (12 px, ascent 10) and not the 18 px wordmark.
Do not "fix" a tall glyph by just raising its ascent — `ascent = height - 2` keeps it
out of the row but pushes the art above the header bar where there is no background.

**Scoreboard names cannot contain spaces.** `/scoreboard players set "Purple Elytrians" asc 12`
is legal in chat but fails inside a `.mcfunction`:

```
Expected whitespace to end one argument, but found trailing data ... Elytrians
```

because the score-holder argument reads a single unquoted word. So the score holder is
one word and 26.3's per-score display name carries the real label:

```mcfunction
scoreboard players set Elytrians asc 12
scoreboard players display name Elytrians asc {"text":"Purple Elytrians"}
```

Do **not** work around it with a team prefix like `"  Purple "` — prefixes apply to real
players too, so every member's tab-list entry becomes "Purple Steve".

**Sidebar scores are red by default.** `Hud.displayScoreboardSidebar` uses
`objective.numberFormatOrDefault(StyledFormat.SIDEBAR_DEFAULT)`, and `SIDEBAR_DEFAULT`
is a red style. An objective-level number format would paint every row the same colour,
so each row sets its own:

```mcfunction
scoreboard players display numberformat Elytrians asc styled {"color":"light_purple"}
```

**Datapack format for 26.3.** `pack.mcmeta` needs `min_format: 121` (26.3's
`data_major`). Anything declaring a `min_format` in 15–81 must also carry
`supported_formats`, otherwise 26.3 rejects the pack outright and `/reload` silently
does nothing. `data_major` / `resource_major` come from `version.json` inside
`minecraft-<ver>-client.jar`.
